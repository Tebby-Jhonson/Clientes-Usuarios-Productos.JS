// Importar los módulos necesarios
const express = require('express');
const app = express();
const path = require('path');

// Configurar la ubicación de las vistas y el motor de plantillas EJS
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Definir la ruta para mostrar la página de inicio
app.get('/', (req, res) => {
    res.render('index');
});

// Definir la ruta para mostrar el menú
app.get('/menu', (req, res) => {
    // Aquí puedes agregar la lógica para obtener los datos del menú si es necesario
    // Luego renderiza la plantilla correspondiente
    res.render('menu');
});

// Definir la ruta para mostrar la página de productos
app.get('/productos', (req, res) => {
    // Suponiendo que tienes una variable "productos" con los datos de los productos
    const productos = ['Xbox One Series X', 'PS5', 'PC Gamer', 'Nintendo Switch'];
    // Renderizar la plantilla productos.ejs y pasar los datos de los productos
    res.render('productos', { productos });
});

// Definir la ruta para mostrar la página de clientes
app.get('/clientes', (req, res) => {
    res.render('clientes');
});

// Definir la ruta para mostrar la página de usuarios
app.get('/usuarios', (req, res) => {
    res.render('usuarios');
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log('Servidor iniciado en http://localhost:3000');
});
